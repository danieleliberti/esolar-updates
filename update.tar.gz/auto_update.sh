#!/bin/bash

# auto_update.sh
# Controlla e installa aggiornamenti da un server remoto.

# --- CONFIGURAZIONE ---
PASS="36e44c9b64"
UPDATE_BASE_URL="https://raw.githubusercontent.com/danieleliberti/esolar-updates/main"
INSTALL_DIR="/apps/bin/3be_update"
LOCAL_VERSION_FILE="$INSTALL_DIR/version.txt"
TEMP_DIR="/tmp/3be_update_pkg"
ARCHIVE_NAME="update.tar.gz"
BOT_TOKEN="8480177538:AAHYwK7NIygQiyx560GLcMvJ6dwZsoa2L9o"

# --- FUNZIONI ---
send_telegram_message() {
    local chat_id="$1"
    local text="$2"
    # Escape JSON
    local json_text=$(echo "$text" | sed 's/\\/\\\\/g' | sed 's/"/\\"/g' | sed ':a;N;$!ba;s/\n/\\n/g')
    wget -qO- --header="Content-Type: application/json" \
         --post-data="{\"chat_id\":\"$chat_id\", \"parse_mode\":\"Markdown\", \"text\":\"$json_text\"}" \
         "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" > /dev/null
}

notify_admins() {
    local msg="$1"
    # Recupera ID dalla descrizione del bot (come in telegram_alert.sh)
    local bot_info=$(wget -qO- "https://api.telegram.org/bot$BOT_TOKEN/getMyShortDescription")
    local recipients=$(echo "$bot_info" | sed 's/\\n/ /g' | grep -o '[0-9]\{6,\}')
    
    if [ ! -z "$recipients" ]; then
        for chat_id in $recipients; do
            send_telegram_message "$chat_id" "$msg"
        done
    fi
}

# --- LOGICA ---

# 1. Controlla versione remota (direttamente da GitHub)
echo "🔍 Controllo aggiornamenti in corso..."

RAW_RESPONSE=$(wget -qO- --no-check-certificate "$UPDATE_BASE_URL/version.txt")
REMOTE_VERSION=$(echo "$RAW_RESPONSE" | tr -d '[:space:]')

# Verifica se la risposta è valida (deve essere un numero, non HTML di errore Drive)
if [[ -z "$REMOTE_VERSION" ]] || [[ ! "$REMOTE_VERSION" =~ ^[0-9]+$ ]]; then
    echo "⚠️  Impossibile recuperare la versione remota."
    echo "    Risposta: '$RAW_RESPONSE'"
    exit 0
fi

# Legge versione locale
LOCAL_VERSION="0"
if [ -f "$LOCAL_VERSION_FILE" ]; then
    LOCAL_VERSION=$(cat "$LOCAL_VERSION_FILE")
fi

# Confronto versioni
if [ "$REMOTE_VERSION" -gt "$LOCAL_VERSION" ]; then
    echo "=========================================================="
    echo "🚀 NUOVA VERSIONE TROVATA: $REMOTE_VERSION (Locale: $LOCAL_VERSION)"
    echo "=========================================================="
    
    notify_admins "🔄 *eSolar Update* 🔄
Host: $(hostname)
Rilevata nuova versione: *$REMOTE_VERSION*
Avvio procedura di aggiornamento..."

    # 2. Scarica e prepara
    echo "$PASS" | sudo -S rm -rf "$TEMP_DIR"
    echo "$PASS" | sudo -S mkdir -p "$TEMP_DIR"
    
    # 2. Scarica il file direttamente da GitHub
    echo "$PASS" | sudo -S wget -q --no-check-certificate -O "$TEMP_DIR/$ARCHIVE_NAME" "$UPDATE_BASE_URL/$ARCHIVE_NAME"
    
    if [ ! -f "$TEMP_DIR/$ARCHIVE_NAME" ]; then
        notify_admins "❌ Errore download aggiornamento su $(hostname)."
        exit 1
    fi

    # 3. Estrae ed esegue l'installer
    echo "$PASS" | sudo -S tar -xzf "$TEMP_DIR/$ARCHIVE_NAME" -C "$TEMP_DIR"
    
    # Cerca lo script di installazione nella cartella estratta
    # Assume che l'archivio contenga la cartella o i file direttamente
    INSTALLER=$(find "$TEMP_DIR" -name "3be_update.sh" | head -n 1)
    
    if [ -f "$INSTALLER" ]; then
        echo "$PASS" | sudo -S chmod +x "$INSTALLER"
        # Esegue l'aggiornamento (l'installer si occuperà di sovrascrivere i file in /apps/bin/...)
        cd "$(dirname "$INSTALLER")" && echo "$PASS" | sudo -S bash 3be_update.sh
        
        if [ $? -eq 0 ]; then
            notify_admins "✅ *eSolar Update Completato* ✅
Host: $(hostname)
Versione installata: *$REMOTE_VERSION*
Il sistema è stato aggiornato con successo."
        else
            notify_admins "❌ *eSolar Update Fallito* ❌
Host: $(hostname)
Errore durante l'installazione della versione $REMOTE_VERSION."
        fi
    fi
else
    echo "=========================================================="
    echo "✅ NESSUN AGGIORNAMENTO. Versione corrente: $LOCAL_VERSION"
    echo "=========================================================="
fi