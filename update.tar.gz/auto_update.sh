#!/bin/bash

# auto_update.sh
# Controlla e installa aggiornamenti da un server remoto.

#
# CONFIGURAZIONE
#
PASS="36e44c9b64"
UPDATE_BASE_URL="https://raw.githubusercontent.com/danieleliberti/esolar-updates/main"
INSTALL_DIR="/apps/bin/3be_update"
LOCAL_VERSION_FILE="$INSTALL_DIR/version.txt"
TEMP_DIR="/tmp/3be_update_pkg"
ARCHIVE_NAME="update.tar.gz"
BOT_TOKEN="8480177538:AAHYwK7NIygQiyx560GLcMvJ6dwZsoa2L9o"

#
# AUTO-ELEVATION TO ROOT
#
if [ "$EUID" -ne 0 ]; then
    echo "Relaunching as root..."
    echo "$PASS" | sudo -S bash "$0" "$@"
    exit $?
fi

#
# FUNZIONI
#
send_telegram_message() {
    local chat_id="$1"
    local text="$2"
    # Escape JSON
    local json_text=$(echo "$text" | sed 's/\\/\\\\/g' | sed 's/"/\\"/g' | sed ':a;N;$!ba;s/\n/\\n/g')
    wget -qO- --header="Content-Type: application/json" \
         --post-data="{\"chat_id\":\"$chat_id\", \"parse_mode\":\"Markdown\", \"text\":\"$json_text\"}" \
         "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" > /dev/null
}

notify_admins() {
    local msg="$1"
    #
    # Recupera ID dalla descrizione del bot (come in telegram_alert.sh)
    #
    local bot_info=$(wget -qO- "https://api.telegram.org/bot$BOT_TOKEN/getMyShortDescription")
    local recipients=$(echo "$bot_info" | sed 's/\\n/ /g' | grep -o '[0-9]\{6,\}')
    
    if [ ! -z "$recipients" ]; then
        for chat_id in $recipients; do
            send_telegram_message "$chat_id" "$msg"
        done
    fi
}

#
# LOGICA
#

#
# 1. Controlla versione remota (direttamente da GitHub)
#
echo "Controllo aggiornamenti in corso..."

RAW_RESPONSE=$(wget -qO- --no-check-certificate "$UPDATE_BASE_URL/version.txt")
REMOTE_VERSION=$(echo "$RAW_RESPONSE" | tr -d '[:space:]')

#
# Verifica se la risposta è valida (deve essere un numero, non HTML di errore Drive)
#
if [[ -z "$REMOTE_VERSION" ]] || [[ ! "$REMOTE_VERSION" =~ ^[0-9]+$ ]]; then
    echo "WARNING: Impossibile recuperare la versione remota."
    echo "    Risposta: '$RAW_RESPONSE'"
    exit 0
fi

#
# Legge versione locale
#
LOCAL_VERSION="0"
if [ -f "$LOCAL_VERSION_FILE" ]; then
    LOCAL_VERSION=$(cat "$LOCAL_VERSION_FILE")
fi

#
# Confronto versioni
#
if [ "$REMOTE_VERSION" -gt "$LOCAL_VERSION" ]; then
    echo "=========================================================="
    echo "NUOVA VERSIONE TROVATA: $REMOTE_VERSION (Locale: $LOCAL_VERSION)"
    echo "=========================================================="
    
    #
    # Estrazione Serial Number (DVSN)
    #
    SGHNET_JSON="/apps/bin/sghnet.json"
    DVSN="N/A"
    if [ -f "$SGHNET_JSON" ]; then
        DVSN=$(grep -o '"dvsn":"[^"]*"' "$SGHNET_JSON" | cut -d'"' -f4)
    fi

    #
    # Recupera Changelog
    #
    CHANGELOG=$(wget -qO- --no-check-certificate "$UPDATE_BASE_URL/changelog.txt")
    [ -z "$CHANGELOG" ] && CHANGELOG="Nessun dettaglio disponibile."

    notify_admins "*eSolar Update*
Host: $(hostname)
Seriale: $DVSN
Rilevata nuova versione: *$REMOTE_VERSION*
Note:
\`\`\`
$CHANGELOG
\`\`\`
Avvio procedura di aggiornamento..."

    #
    # 2. Scarica e prepara
    #
    rm -rf "$TEMP_DIR"
    mkdir -p "$TEMP_DIR"
    
    wget -q --no-check-certificate -O "$TEMP_DIR/$ARCHIVE_NAME" "$UPDATE_BASE_URL/$ARCHIVE_NAME"
    
    if [ ! -f "$TEMP_DIR/$ARCHIVE_NAME" ]; then
        notify_admins "ERROR: Errore download aggiornamento su $(hostname) (Seriale: $DVSN)."
        exit 1
    fi

    #
    # 3. Estrae ed esegue l'installer
    #
    tar -xzf "$TEMP_DIR/$ARCHIVE_NAME" -C "$TEMP_DIR"
    
    #
    # Cerca lo script di installazione nella cartella estratta
    # Assume che l'archivio contenga la cartella o i file direttamente
    #
    INSTALLER=$(find "$TEMP_DIR" -name "3be_update.sh" | head -n 1)
    
    if [ -f "$INSTALLER" ]; then
        chmod +x "$INSTALLER"
        #
        # Esegue l'aggiornamento (l'installer si occuperà di sovrascrivere i file in /apps/bin/...)
        #
        cd "$(dirname "$INSTALLER")" && bash 3be_update.sh
        
        if [ $? -eq 0 ]; then
            notify_admins "*eSolar Update Completato*
Host: $(hostname)
Seriale: $DVSN
Versione installata: *$REMOTE_VERSION*
Note:
\`\`\`
$CHANGELOG
\`\`\`
Il sistema è stato aggiornato con successo."
        else
            notify_admins "*eSolar Update Fallito*
Host: $(hostname)
Seriale: $DVSN
Note:
\`\`\`
$CHANGELOG
\`\`\`
Errore durante l'installazione della versione $REMOTE_VERSION."
        fi
    fi
else
    echo "=========================================================="
    echo "NESSUN AGGIORNAMENTO. Versione corrente: $LOCAL_VERSION"
    echo "=========================================================="
fi