#!/bin/bash

# --- CONFIGURATION ---
PASS="36e44c9b64"
LOG_FILE="/var/log/messages"
BAR="=========================================================="

# Function for a rotating spinner during status updates
execute_with_spinner() {
    local msg=$1
    local cmd=$2
    local spinner="/-\|"
    
    eval "$cmd" > /dev/null 2>&1 &
    local pid=$! 
    
    while kill -0 $pid 2>/dev/null; do
        for i in {0..3}; do
            echo -ne "\r\e[K[ ${spinner:$i:1} ] $msg..."
            sleep 0.1
        done
    done
}

confirm_step() {
    local msg=$1
    echo -e "\r\e[K[ \e[32mOK\e[0m ] $msg"
}

echo "$BAR"
echo "   eSolar SYSTEM MAINTENANCE START"
echo "$BAR"

# 1. FILESYSTEM
echo -e "\n[1/6] FILESYSTEM OPERATIONS"
execute_with_spinner "Accessing Desktop directory" "cd /home/sinapsi/Desktop/"
execute_with_spinner "Executing remount_rw (Escalating privileges)" "echo '$PASS' | sudo -S bash remount_rw"
execute_with_spinner "Executing root_rw.sh start" "cd /home/sinapsi/Desktop/ && echo '$PASS' | sudo -S $(which service) root_rw.sh start"

confirm_step "Root filesystem remounted in RW mode"

# 2. CRONTAB
echo -e "\n[2/6] CRON SCHEDULING"
execute_with_spinner "Generating rules (Reboot, Cache, Logs, HB, Alert, AutoUpdate)" "echo '# Daily Reboot' > /tmp/new_cron && echo '0 2 * * * /sbin/reboot' >> /tmp/new_cron && echo '# Clear Memory Cache' >> /tmp/new_cron && echo '5 * * * * sync; echo 3 > /proc/sys/vm/drop_caches;' >> /tmp/new_cron && echo '# System Heartbeat' >> /tmp/new_cron && echo '* * * * * /bin/date > /tmp/hb' >> /tmp/new_cron && echo '# Log Rotation' >> /tmp/new_cron && echo '*/5 * * * * /usr/sbin/logrotate /etc/logrotate.conf' >> /tmp/new_cron && echo '# Supervisor Restart' >> /tmp/new_cron && echo '*/30 * * * * sudo supervisorctl restart all >/dev/null 2>&1' >> /tmp/new_cron && echo '# Telegram Alert' >> /tmp/new_cron && echo '@reboot /bin/bash /apps/bin/3be_update/telegram_alert.sh >/dev/null 2>&1' >> /tmp/new_cron && echo '*/5 * * * * /bin/bash /apps/bin/3be_update/telegram_alert.sh >/dev/null 2>&1' >> /tmp/new_cron && echo '# Auto Update Check' >> /tmp/new_cron && echo '*/10 * * * * /bin/bash /apps/bin/3be_update/auto_update.sh >/dev/null 2>&1' >> /tmp/new_cron"
execute_with_spinner "Installing Crontab for root user" "echo '$PASS' | sudo -S crontab -u root /tmp/new_cron"
execute_with_spinner "Clearing sinapsi crontab" "echo '$PASS' | sudo -S crontab -u sinapsi -r || true"
rm /tmp/new_cron
confirm_step "Root Schedule updated & Sinapsi cleared"

# 3. LOGROTATE
echo -e "\n[3/6] LOG MANAGEMENT CONFIG"
execute_with_spinner "Creating logrotate policy (500k limit)" "cat <<EOF > /tmp/custom_logrotate
$LOG_FILE {
    size 500k
    copytruncate
    rotate 2
    compress
    missingok
    notifempty
}
EOF"
execute_with_spinner "Applying configuration to /etc/logrotate.d/" "echo '$PASS' | sudo -S mv /tmp/custom_logrotate /etc/logrotate.d/custom_logs && echo '$PASS' | sudo -S chown root:root /etc/logrotate.d/custom_logs && echo '$PASS' | sudo -S chmod 644 /etc/logrotate.d/custom_logs"
echo "Verifying configuration syntax..."
echo '$PASS' | sudo -S logrotate -d /etc/logrotate.d/custom_logs > /dev/null 2>&1
confirm_step "Log limit policy activated"

# 4. LOG PURGE
echo -e "\n[4/6] IMMEDIATE LOG PURGE"
# Using 'truncate -s 0' is the cleanest way to empty logs without deleting the file descriptors
execute_with_spinner "Truncating all log files in /var/log" "echo '$PASS' | sudo -S find /var/log -type f -name '*.log' -exec truncate -s 0 {} + && echo '$PASS' | sudo -S find /var/log -type f -name 'messages*' -exec truncate -s 0 {} +"
confirm_step "All system logs under /var/log have been emptied"

# 5. ESOLAR HUB SYNC
echo -e "\n[5/6] ESOLAR HUB SYNC INSTALLATION"
echo '$PASS' | sudo -S mkdir -p /apps/bin/3be_update/esolarhub/
(echo '$PASS' | sudo -S cp -r esolarhub/* /apps/bin/3be_update/esolarhub/ 2>&1) | grep -v "same file"
echo '$PASS' | sudo -S chmod +x /apps/bin/3be_update/esolarhub/*.sh
(echo '$PASS' | sudo -S cp health_check.sh telegram_alert.sh auto_update.sh version.txt /apps/bin/3be_update/ 2>&1) | grep -v "same file"
echo '$PASS' | sudo -S chmod +x /apps/bin/3be_update/health_check.sh /apps/bin/3be_update/telegram_alert.sh /apps/bin/3be_update/auto_update.sh
(echo '$PASS' | sudo -S cp esolarhub/snpds_sync_sprvsr.conf /etc/supervisor/conf.d/snpds_sync_sprvsr.conf 2>&1) | grep -v "same file"
echo '$PASS' | sudo -S supervisorctl reload
for i in {10..1}; do
    echo -ne "\r[WAIT] Riavvio servizi in corso... $i "
    sleep 1
done
echo -e "\r\e[K"
echo '$PASS' | sudo -S supervisorctl status
echo '$PASS' | sudo -S bash /apps/bin/3be_update/telegram_alert.sh >/dev/null 2>&1
confirm_step "Service installed"

# 6. FINALIZATION
echo -e "\n[6/6] VERIFICATION & CLEANUP"
echo -ne "[WAIT] Verifying system crontab integrity..."
sleep 1
echo -e "\r\e[K--- Active Root Crontab Summary ---"
echo "$PASS" | sudo -S crontab -l
echo "------------------------------------"

echo -e "\n[HEALTH CHECK]"
echo "$PASS" | sudo -S bash -c "echo \"[$(date '+%Y-%m-%d %H:%M:%S')] 3be_update: Launching health_check.sh\" >> $LOG_FILE"
echo "$PASS" | sudo -S bash /apps/bin/3be_update/health_check.sh

echo -e "\n$BAR"
echo " OPERATIONS COMPLETED. Returning to user: $(whoami)"
echo "$BAR"