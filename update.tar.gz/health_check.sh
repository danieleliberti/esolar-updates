#!/bin/bash

# health_check.sh
# Esegue un controllo dello stato di salute dei componenti critici del sistema eSolar.

# --- Configurazione ---
LOG_SYNC="/var/log/esoalrhub_sync.log"
LOG_MESSAGES="/var/log/syslog"
DISK_USAGE_THRESHOLD=92 # Soglia di allarme in percentuale
HEARTBEAT_FILE="/tmp/hb"
HEARTBEAT_MAX_AGE=120 # Età massima in secondi del file heartbeat

# --- Colori per l'output ---
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_NC='\033[0m' # Nessun colore

# --- Funzioni di utilità ---
print_status() {
    local status=$1
    local message=$2
    if [ "$status" == "OK" ]; then
        echo -e "[ ${COLOR_GREEN}OK${COLOR_NC} ] $message"
    elif [ "$status" == "WARN" ]; then
        echo -e "[ ${COLOR_YELLOW}WARN${COLOR_NC} ] $message"
    else
        echo -e "[ ${COLOR_RED}FAIL${COLOR_NC} ] $message"
    fi
}

# --- Funzioni di controllo ---

check_filesystem() {
    echo -e "\n--- 1. Stato del Filesystem ---"
    if mount | grep 'on / ' | grep -q 'rw,'; then
        print_status "OK" "Il filesystem di root è montato in lettura-scrittura (RW)."
    else
        print_status "OK" "Il filesystem di root è in modalità protetta (RO)."
    fi
}

check_disk_space() {
    echo -e "\n--- 2. Spazio su Disco ---"
    # Controlla la partizione di root
    df -h / | tail -n 1 | while read -r fs size used avail use p; do
        usage=$(echo "$use" | sed 's/%//')
        if [ "$usage" -gt "$DISK_USAGE_THRESHOLD" ]; then
            print_status "FAIL" "Utilizzo partizione di root (${p}) è ${use}, superiore alla soglia (${DISK_USAGE_THRESHOLD}%)."
        else
            print_status "OK" "Utilizzo partizione di root (${p}) è ${use}."
        fi
    done
}

check_services() {
    echo -e "\n--- 3. Servizi di Base ---"
    # Controlla supervisord
    if pgrep supervisord > /dev/null; then
        print_status "OK" "Il demone Supervisor è in esecuzione."
    else
        print_status "FAIL" "Il demone Supervisor NON è in esecuzione."
        return
    fi

    # Controlla cron
    if pgrep cron > /dev/null; then
        print_status "OK" "Il demone Cron è in esecuzione."
    else
        print_status "FAIL" "Il demone Cron NON è in esecuzione."
    fi
}

check_supervisor_apps() {
    echo -e "\n--- 4. Applicazioni Supervisionate ---"
    if ! command -v supervisorctl &> /dev/null; then
        print_status "FAIL" "Comando 'supervisorctl' non trovato. Impossibile verificare le applicazioni."
        return
    fi

    # Controlla lo stato di snpds_sync
    # Cattura output per evitare race conditions e incongruenze
    local snpds_output=$(supervisorctl status | grep "snpds_sync")
    
    # Considera OK sia RUNNING che STARTING (stato transitorio valido)
    if echo "$snpds_output" | grep -E -q 'RUNNING|STARTING'; then
        local current_status=$(echo "$snpds_output" | awk '{print $2}')
        print_status "OK" "L'applicazione 'snpds_sync' è in stato ${current_status}."
    else
        local SNPDS_STATUS=$(echo "$snpds_output" | awk '{print $2}')
        print_status "FAIL" "L'applicazione 'snpds_sync' è in stato: ${SNPDS_STATUS:-NON TROVATA}."
        print_status "FAIL" "Supervisor Output: $snpds_output"
    fi
}

check_heartbeat() {
    echo -e "\n--- 5. Heartbeat di Sistema (Cron) ---"
    if [ ! -f "$HEARTBEAT_FILE" ]; then
        print_status "FAIL" "File di heartbeat ($HEARTBEAT_FILE) non trovato. Cron potrebbe non funzionare."
        return
    fi

    local last_mod
    last_mod=$(stat -c %Y "$HEARTBEAT_FILE")
    local now
    now=$(date +%s)
    local age=$((now - last_mod))

    if [ "$age" -gt "$HEARTBEAT_MAX_AGE" ]; then
        print_status "FAIL" "L'heartbeat è vecchio. Ultimo aggiornamento $age secondi fa (soglia: $HEARTBEAT_MAX_AGE)."
    else
        print_status "OK" "L'heartbeat è attivo. Ultimo aggiornamento $age secondi fa."
    fi
}

check_logs() {
    echo -e "\n--- 6. Analisi dei Log ---"
    # Controlla syslog, sync log e sghnet log
    local logs=("$LOG_MESSAGES" "$LOG_SYNC" "/var/log/sghnet.log")

    for log_file in "${logs[@]}"; do
        if [ -f "$log_file" ] && [ -r "$log_file" ]; then
            ERRORS=$(tail -n 100 "$log_file" | grep -iE "error|fail|critical" | wc -l)
            [ "$ERRORS" -gt 0 ] && print_status "WARN" "Trovati $ERRORS errori in $(basename "$log_file")." || print_status "OK" "Nessun errore in $(basename "$log_file")."
        else
            print_status "WARN" "Log $(basename "$log_file") non trovato."
        fi
    done
}

# --- Esecuzione Principale ---
BAR="=========================================================="
echo "$BAR"
echo "         eSolar SYSTEM HEALTH CHECK"
echo "$BAR"

check_filesystem
check_disk_space
check_services
check_supervisor_apps
check_heartbeat
check_logs

echo -e "\n$BAR"
echo "            CONTROLLO COMPLETATO"
echo "$BAR"