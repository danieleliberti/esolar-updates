sudo $(which service) root_rw.sh start
echo "Coping. .. "
sudo cp snpds_sync_sprvsr.conf /etc/supervisor/conf.d/snpds_sync_sprvsr.conf
echo "Reload service conf"
sudo supervisorctl reload
echo "Get status"
sudo supervisorctl status