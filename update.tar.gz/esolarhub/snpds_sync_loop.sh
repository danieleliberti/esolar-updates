#!/bin/bash

while true; do
    TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$TIMESTAMP] Avvio sincronizzazione..."
    bash ./snpds_sync.sh
    echo "[$TIMESTAMP] Attendo 30 secondi..."
    sleep 30
done