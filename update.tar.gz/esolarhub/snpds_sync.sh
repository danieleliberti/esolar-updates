#!/bin/bash
echo "[INFO] Versione build 2504231532"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CREDENTIALS_FILE="$SCRIPT_DIR/snpds_sync.cnf"
CONFIG_FILE="${1:-$SCRIPT_DIR/dbsync.conf}"

if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "[ERRORE] Configurazione non trovata: $CONFIG_FILE"
    exit 1
fi

if [[ ! -f "$CREDENTIALS_FILE" ]]; then
    echo "[ERRORE] File credenziali non trovato: $CREDENTIALS_FILE"
    exit 1
fi

source "$CONFIG_FILE"

BASE_DB=$(mysql --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix="" \
  -h "$SRC_HOST" "$SRC_DB" -N -B -e "SELECT nodeserialnumber FROM esolar.snpds_servernode LIMIT 1;")

if [[ -z "$BASE_DB" ]]; then
    echo "[ERRORE] Impossibile ottenere nodeserialnumber da snpds_servernode"
    exit 1
fi

DST_DB="${BASE_DB}_${SRC_DB}"
echo "[INFO] Database destinazione: $DST_DB"

DB_EXISTS=$(mysql --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix=dest \
  -h "$DST_HOST" -N -B -e "SHOW DATABASES LIKE '${DST_DB}';")

if [[ -z "$DB_EXISTS" ]]; then
    echo "[INFO] Il database '$DST_DB' non esiste. Lo creo..."
    mysql --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix=dest \
      -h "$DST_HOST" -e "CREATE DATABASE \`${DST_DB}\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
    echo "[OK] Database '$DST_DB' creato."
else
    echo "[INFO] Il database '$DST_DB' esiste già."
fi

FINAL_DST_TABLE="${SRC_TABLE}${DST_TABLE_SUFFIX}"

TMP_DIR="/tmp/dbsync_hash"
mkdir -p "$TMP_DIR"

SRC_HASH="$TMP_DIR/src_hash.txt"
DST_HASH="$TMP_DIR/dst_hash.txt"
TO_UPDATE="$TMP_DIR/ids_to_update.txt"
DUMP_FILE="$TMP_DIR/rows_to_sync.sql"
CREATE_FILE="$TMP_DIR/create_table.sql"
MODIFIED_CREATE_FILE="$TMP_DIR/create_table_modified.sql"

TABLE_EXISTS=$(mysql --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix=dest \
  -h "$DST_HOST" "$DST_DB" -N -B -e "SHOW TABLES LIKE '${FINAL_DST_TABLE}';")

if [[ -z "$TABLE_EXISTS" ]]; then
    echo "[INFO] Creo tabella '$FINAL_DST_TABLE' nel DB '$DST_DB'..."

    mysqldump --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix="" \
      -h "$SRC_HOST" "$SRC_DB" "$SRC_TABLE" --no-data --skip-lock-tables > "$CREATE_FILE"

    if [[ ! -s "$CREATE_FILE" ]]; then
        echo "[ERRORE] Dump struttura vuoto. Verifica sorgente."
        exit 1
    fi

    sed "s/\`$SRC_TABLE\`/\`$FINAL_DST_TABLE\`/g" "$CREATE_FILE" > "$MODIFIED_CREATE_FILE"

    mysql --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix=dest \
      -h "$DST_HOST" "$DST_DB" < "$MODIFIED_CREATE_FILE"

    echo "[OK] Tabella '$FINAL_DST_TABLE' creata."
else
    echo "[INFO] Tabella '$FINAL_DST_TABLE' già esistente."
fi

COLUMNS=$(mysql --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix="" \
  -h "$SRC_HOST" "$SRC_DB" -N -B -e \
  "SHOW COLUMNS FROM $SRC_TABLE" | awk '$1 != "id" {print $1}' | paste -sd',' -)

if [[ -z "$COLUMNS" ]]; then
    echo "[ERRORE] Nessuna colonna trovata nella sorgente."
    exit 1
fi

HASH_EXPR=$(echo "$COLUMNS" | awk -F',' '{
    out = "MD5(CONCAT_WS(\"#\""
    for (i=1; i<=NF; i++) out = out ", IFNULL(" $i ", \"NULL\")"
    out = out "))"
    print out
}')

mysql --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix="" \
  -h "$SRC_HOST" "$SRC_DB" -N -B -e \
  "SELECT id, $HASH_EXPR FROM $SRC_TABLE" > "$SRC_HASH"

mysql --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix=dest \
  -h "$DST_HOST" "$DST_DB" -N -B -e \
  "SELECT id, $HASH_EXPR FROM $FINAL_DST_TABLE" > "$DST_HASH"

if [[ ! -s "$DST_HASH" ]]; then
    echo "[INFO] Tabella destinazione vuota. Copio tutti i dati..."

    mysqldump --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix="" \
      -h "$SRC_HOST" "$SRC_DB" "$SRC_TABLE" \
      --skip-lock-tables --no-create-info --replace > "$DUMP_FILE"

    sed -i "s/\`$SRC_TABLE\`/\`$FINAL_DST_TABLE\`/g" "$DUMP_FILE"

    mysql --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix=dest \
      -h "$DST_HOST" "$DST_DB" < "$DUMP_FILE"

    echo "[OK] Tutti i record sono stati copiati."
else
    echo "[INFO] Confronto hash per modifiche/inserimenti..."

    # ID con hash diversi
    awk 'NR==FNR {a[$1]=$2; next} a[$1] != $2 {print $1}' "$DST_HASH" "$SRC_HASH" > "$TO_UPDATE"

    # ID nuovi presenti solo nella sorgente
    awk 'NR==FNR {a[$1]=$2; next} !($1 in a) {print $1}' "$DST_HASH" "$SRC_HASH" >> "$TO_UPDATE"

    if [[ -s "$TO_UPDATE" ]]; then
        echo "[INFO] Righe da sincronizzare: $(wc -l < "$TO_UPDATE")"
        IDS=$(paste -sd, "$TO_UPDATE")

        mysqldump --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix="" \
          -h "$SRC_HOST" "$SRC_DB" "$SRC_TABLE" \
          --skip-lock-tables --no-create-info --replace \
          --where="id IN ($IDS)" > "$DUMP_FILE"

        sed -i "s/\`$SRC_TABLE\`/\`$FINAL_DST_TABLE\`/g" "$DUMP_FILE"

        mysql --defaults-file="$CREDENTIALS_FILE" --defaults-group-suffix=dest \
          -h "$DST_HOST" "$DST_DB" < "$DUMP_FILE"

        echo "[OK] Righe sincronizzate."
    else
        echo "[INFO] Nessuna modifica o nuovo record da sincronizzare."
    fi
fi

rm -f "$SRC_HASH" "$DST_HASH" "$TO_UPDATE" "$DUMP_FILE" "$CREATE_FILE" "$MODIFIED_CREATE_FILE"