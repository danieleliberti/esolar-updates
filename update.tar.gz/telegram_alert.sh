#!/bin/bash

# telegram_alert.sh
# Wrapper per health_check.sh che invia notifiche Telegram in caso di errori.

#
# CONFIGURAZIONE TELEGRAM
#
BOT_TOKEN="8480177538:AAHYwK7NIygQiyx560GLcMvJ6dwZsoa2L9o"

#
# PERCORSI
#
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
HEALTH_CHECK_SCRIPT="$SCRIPT_DIR/health_check.sh"
SGHNET_JSON="/apps/bin/sghnet.json"

#
# FUNZIONI UTILI
#
send_telegram_message() {
    local chat_id="$1"
    local text="$2"
    
    # Escape per JSON: backslash, doppi apici e conversione newline in \n letterale
    local json_text=$(echo "$text" | sed 's/\\/\\\\/g' | sed 's/"/\\"/g' | sed ':a;N;$!ba;s/\n/\\n/g')
    
    wget -qO- --header="Content-Type: application/json" \
         --post-data="{\"chat_id\":\"$chat_id\", \"parse_mode\":\"Markdown\", \"text\":\"$json_text\"}" \
         "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" > /dev/null
}

#
# LOGICA
#

#
# Verifica esistenza script
#
if [ ! -f "$HEALTH_CHECK_SCRIPT" ]; then
    echo "CRITICAL: $HEALTH_CHECK_SCRIPT non trovato!"
    exit 1
fi

#
# Esegue health_check e cattura l'output
# sed rimuove i codici colore ANSI per l'analisi testuale
#
OUTPUT=$(bash "$HEALTH_CHECK_SCRIPT")
CLEAN_OUTPUT=$(echo "$OUTPUT" | sed -r "s/\x1B\[([0-9]{1,2}(;[0-9]{1,2})?)?[mGK]//g")

#
# Cerca errori (FAIL)
#
FAILURES=$(echo "$CLEAN_OUTPUT" | grep "FAIL")

if [ ! -z "$FAILURES" ]; then
    HOSTNAME=$(hostname)
    TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
    
    #
    # Estrazione Serial Number (DVSN)
    #
    DVSN="N/A"
    if [ -f "$SGHNET_JSON" ]; then
        DVSN=$(grep -o '"dvsn":"[^"]*"' "$SGHNET_JSON" | cut -d'"' -f4)
    fi
    
    #
    # Raccolta metriche sistema
    #
    DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}')
    RAM_USAGE=$(free -m | awk '/Mem:/ { printf("%d/%d MB (%.1f%%)", $3, $2, $3/$2*100) }')
    CPU_LOAD=$(cat /proc/loadavg | awk '{print $1", "$2", "$3}')

    #
    # Costruzione messaggio con newlines reali e blocco codice per i log
    #
    MESSAGE="*eSolar ALERT*
Host: $HOSTNAME
Seriale: $DVSN
Orario: $TIMESTAMP

*Stato Risorse:*
Disk: $DISK_USAGE
RAM: $RAM_USAGE
CPU Load: $CPU_LOAD

*Problemi Rilevati:*
\`\`\`
$FAILURES
\`\`\`"
    
    #
    # 1. Scarica la descrizione del bot in tempo reale
    #
    BOT_INFO=$(wget -qO- "https://api.telegram.org/bot$BOT_TOKEN/getMyShortDescription")
    
    #
    # 2. Estrae gli ID autorizzati (numeri di almeno 6 cifre)
    #
    RECIPIENTS=$(echo "$BOT_INFO" | sed 's/\\n/ /g' | grep -o '[0-9]\{6,\}')
    
    #
    # 3. Invia notifica a ciascun ID trovato
    #
    if [ ! -z "$RECIPIENTS" ]; then
        for chat_id in $RECIPIENTS; do
            send_telegram_message "$chat_id" "$MESSAGE"
        done
    fi
fi